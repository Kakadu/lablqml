String.prototype.startsWith = function(str)
{return (this.match("^"+str)!==str)}
