let on_return_pressed () = 
        print_endline "return pressed";
        flush stdout

