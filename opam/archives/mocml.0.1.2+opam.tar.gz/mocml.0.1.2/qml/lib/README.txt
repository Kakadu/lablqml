(* OASIS_START *)
(* DO NOT EDIT (digest: f613cb934b9db21d9d4f02a28e2382c9) *)
This is the README file for the qml_wrap distribution.

wrappers for QML objects

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
