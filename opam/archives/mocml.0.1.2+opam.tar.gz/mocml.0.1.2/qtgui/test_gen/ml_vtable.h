/* $Id: ml_vtable.h,v 1.2 1999/02/01 01:08:47 garrigue Exp $ */

value ml_lookup_method (void *obj, value tag);
value ml_delete_object (void *obj);
