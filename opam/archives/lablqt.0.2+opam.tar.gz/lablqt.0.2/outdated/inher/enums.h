#include <QtGui/QtGui>

extern Qt::WindowFlags enum_of_caml_Qt_WindowFlags(value);
extern value enum_to_caml_Qt_WindowFlags(Qt::WindowFlags);
