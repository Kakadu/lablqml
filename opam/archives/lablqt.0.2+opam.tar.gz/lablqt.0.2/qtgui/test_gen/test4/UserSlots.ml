let onclicked b =
        Printf.printf "Put here slot body. argument = %b\n" b;
        flush stdout


