let getwidth () = 400
let () = 
        Callback.register "getwidth" getwidth


