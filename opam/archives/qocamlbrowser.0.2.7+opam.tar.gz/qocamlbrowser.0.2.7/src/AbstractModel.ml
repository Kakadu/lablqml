open QmlContext

class virtual abstractModel = object
  method virtual hardcodedIndex: int [@@qtprop]
end[@@itemmodel][@@qtclass]

