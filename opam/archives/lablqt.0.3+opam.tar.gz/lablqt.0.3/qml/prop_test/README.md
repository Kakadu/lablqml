This is very small "Hello World!"-like application using OCaml and QtQuick 2.0 from Qt5.

It is a demo for lablqt (outdated) introduction from:
    https://github.com/Kakadu/lablqt/wiki/Using-mocml-with-QtQuick-(description-of-hallo-world-app)
New helloworld tutorial can be found at: http://kakadu.github.io/lablqt/qtquick-helloworld.html

N.B. This example is not built automatically by `$LABLQT_ROOT/qml/configure`.

N.B. Don't forget that QtQuick 1.0 == QtDeclarative from Qt 4.x,
QtQuick 2.0 == QtDeclarative from Qt5.

