open QmlContext

class virtual intModel = object(self)
end[@@qtclass][@@itemmodel]
