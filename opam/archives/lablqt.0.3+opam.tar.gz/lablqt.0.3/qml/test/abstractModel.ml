open QmlContext

class virtual abstractModel = object

end[@@itemmodel][@@qtclass]

