There you can find my experienca about interfacing OCaml and Qt.

* QtQuick 2.0 (from Qt5) + OCaml stuff is in `qml/`.
* QtGui + OCaml is probably outdated and not compiled. I have paused my work with it. See build environment in `qtgui/`
* Both project share same codegenerator which is located in `src/`

See corresponding READMEs for more details

Happy hacking,
Kakadu

